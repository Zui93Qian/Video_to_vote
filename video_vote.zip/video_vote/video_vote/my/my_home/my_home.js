// pages/my/my_home/my_home.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    body:false,
    butTab:0,
    lefr_height: 0,
    right_height: 0,
    text_left: [],
    text_right: [],
    my_works_data1:[],
    my_works_data: []
  },
  //报名
  tap_myApply(){
    wx.navigateTo({
      url: '../../my/my_apply/my_apply',
    })
  },
  tap_butTab(e){
    var _that = this;
    var inx = e.currentTarget.dataset.inx;
      this.setData({
        butTab: inx
      })
  },
  //视频详情
  tao_imgTab(e) {
    var id = e.currentTarget.dataset.id;
    var uid = wx.getStorageSync('uid');
    console.log(id,uid)
    wx.navigateTo({
      url: '../../classify/details/details?id=' + id + '&uid=' + uid,
    })
  },
  //全部鲜花消息
  tap_flowerAll(){
    wx.navigateTo({
      url: '../../my/flower_All/flower_All',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _that = this
    var uid = wx.getStorageSync('uid');
    _that.setData({
      winWid: wx.getSystemInfoSync().windowWidth / 2
    })
    _that.load('', uid);
  },
  load: function (options, uid, type) {
    var _that = this;
    var lefr_height = _that.data.lefr_height;
    var right_height = _that.data.right_height;
    var leftList = _that.data.text_left;
    var reightList = _that.data.text_right;
    app.util.request({
      url: 'entry/wxapp/my',
      data: {
        uid: uid
      },
      headers: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        console.log(res.data.data)
        var text_data = res.data.data.my_collect
        var winWid = _that.data.winWid
        _that.setData({
          my_info: res.data.data.my_info,
          lately_play:res.data.data.lately_play,
          my_works: res.data.data.my_works,
          is_apply: res.data.data.is_apply,
          body:true
        })
        for (var i = 0; i < text_data.length; i++) {
          var imgh = text_data[i].height; //图片高度
          var imgw = text_data[i].width; //图片宽度
          var swiperH = parseInt(winWid * imgh / imgw)
          text_data[i].height = swiperH
          if (lefr_height == right_height) {
            lefr_height += text_data[i].height;
            leftList.push(text_data[i]);
          } else if (lefr_height > right_height) {
            right_height += text_data[i].height;
            reightList.push(text_data[i]);
          } else {
            lefr_height += text_data[i].height;
            leftList.push(text_data[i]);
          }
          console.log(text_data[i].height, lefr_height, right_height)
          _that.setData({
            text_data: text_data,
            lefr_height: lefr_height,
            right_height: right_height,
            text_left: leftList,
            text_right: reightList
          })
        }
      }
    })
  },
  unset(_that) {
    _that.setData({
      lefr_height: 0,
      right_height: 0,
      text_left: [],
      text_right: []
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var uid = wx.getStorageSync('uid');
    this.unset(this);
    this.load('', uid);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})