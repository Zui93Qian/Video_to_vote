// pages/my/my_apply/my_apply.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    body:false,
    list_data:[],
    id: null,
    list:0
  },
  tap_list(e){
    var inx = e.currentTarget.dataset.inx
    var id = e.currentTarget.dataset.id
    this.setData({
      list: inx,
      id: id
    })
  },
  formSubmit(e){
    var _that = this
    var mobiles = /^[1][3,4,5,7,8][0-9]{9}$/;
    var mobile = e.detail.value.mobile
    var isMobile = mobiles.exec(mobile)
    var username = e.detail.value.username
    var formId = e.detail.formId
    var uid = wx.getStorageSync('uid');
    var id = _that.data.id
    if (!username) {
      wx.showToast({
        title: '姓名不能为空',
        icon: 'none',
        duration: 2000
      })
      return false
    }
    if (!isMobile) {
      wx.showToast({
        title: '你输入的电话不符，请重新检查填写',
        icon: 'none',
        duration: 2000
      })
      return false
    }
    if (id == null){
      id = _that.data.list_data[0].id
    }
    _that.load(uid, id, username, mobile, formId);
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var uid = wx.getStorageSync('uid');
    this.load(uid);
  },
  load: function (uid, id, username, mobile, formId) {
    var _that = this
    app.util.request({
      url: 'entry/wxapp/apply',
      data: {
        uid: uid,
        category_id: id,
        username:username,
        mobile: mobile,
        formid: formId
      },
      headers: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        console.log(res.data.data)
        if (res.data.data == 1){
          wx.showToast({
            title: '报名成功,等待审核！！',
            icon: 'none',
            duration: 2000,
            success(res){
              wx.navigateBack({
                delta: 2
              })
            }
          })
        }
        _that.setData({
          list_data: res.data.data,
          body:true
        })

      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})