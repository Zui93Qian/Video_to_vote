// video_vote/home/video/video.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    body:false,
    lefr_height: 0,
    right_height: 0,
    text_left: [],
    text_right: [],
    navigation: 0, //小导航
    val:null, //input框
  },
  //获取搜索关键字
  keyword: function(e) {
    var that = this;
    that.setData({
      keyword: e.detail.value
    })
  },
  //搜索
  search: function() {
    var that = this;
    var keyword = that.data.keyword;
    that.unset();
    that.load('', keyword);
  },
  //小导航
  tap_DH(e) {
    var _that = this;
    var inx = e.currentTarget.dataset.navigation;
    _that.setData({
      navigation: inx
    })
    if(inx == 0){
      var type = 'hot'
      var id = _that.data.id
      _that.unset(_that);
      _that.load(id,'',type);
    }
    if (inx == 1) {
      var type = 'news'
      var id = _that.data.id
        _that.unset(_that);
      _that.load(id, '', type);
    }
    if (inx == 2) {
      var id = _that.data.id
      wx.navigateTo({
        url: '../../list/list?type=flower&id='+id,
      })
      _that.setData({
        navigation: 2
      })
    }
  },
  //详情跳转
  tao_imgTab(e) {
    var id = e.currentTarget.dataset.id;
    var uid = wx.getStorageSync('uid');
    wx.navigateTo({
      url: '../../classify/details/details?id=' + id + '&uid=' + uid,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var _that = this
    _that.setData({
      id: options.id
    })
    var id = _that.data.id
    _that.load(id, '','');
    _that.setData({
      winWid: wx.getSystemInfoSync().windowWidth / 2
    })
  },
  load: function (options, keyword, type) {
    var _that = this;
    var lefr_height = _that.data.lefr_height;
    var right_height = _that.data.right_height;
    var leftList = _that.data.text_left;
    var reightList = _that.data.text_right;
    app.util.request({
      url: 'entry/wxapp/cate_video',
      data: {
        id: options,
        keyword:keyword,
        type: type
      },
      headers: {
        'Content-Type': 'application/json'
      },
      success: function(res) {
        var text_data = res.data.data
        var winWid = _that.data.winWid
        _that.setData({
          body:true
        })
        for (var i = 0; i < text_data.length; i++) {
          var imgh = text_data[i].height; //图片高度
          var imgw = text_data[i].width; //图片宽度
          var swiperH = parseInt(winWid * imgh / imgw)
          text_data[i].height = swiperH
          if (lefr_height == right_height) {
            lefr_height += text_data[i].height;
            leftList.push(text_data[i]);
          } else if (lefr_height > right_height) {
            right_height += text_data[i].height;
            reightList.push(text_data[i]);
          } else {
            lefr_height += text_data[i].height;
            leftList.push(text_data[i]);
          }
          console.log(text_data[i].height, lefr_height, right_height)
          _that.setData({
            text_data: text_data,
            lefr_height: lefr_height,
            right_height: right_height,
            text_left: leftList,
            text_right: reightList
          })
        }
      }
    })
  },
  //获取搜索关键字
  keyword: function (e) {
    var that = this;
    that.setData({
      keyword: e.detail.value
    })
  },
  //搜索
  search: function () {
    var _that = this;
    var keyword = _that.data.keyword
    var id = _that.data.id
    var type = _that.data.navigation
    _that.unset(_that)
    _that.load(id, keyword, type);
    _that.setData({
      val: null,
      keyword: ''
    })
  },
  unset(_that){
    _that.setData({
      lefr_height: 0,
      right_height: 0,
      text_left: [],
      text_right: []
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var _that = this
    var id = _that.data.id
    _that.unset(this)
    _that.load(id);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})