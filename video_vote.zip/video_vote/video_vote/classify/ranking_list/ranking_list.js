// pages/classify/ranking_list/ranking_list.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    body:false,
    dis_flo: true,
    flower: null, //默认送花
    inputValue: '输入你要送花的数量',
    flower_my: 0,
  },
  //送花选择
  tap_flowerBtn(e) {
    var _that = this;
    var inx = e.currentTarget.dataset.inx;
    var flower_money = e.currentTarget.dataset.flower_money;
    var uid = wx.getStorageSync('uid');
    var id = _that.data.id
    app.util.request({
      'url': 'entry/wxapp/pay', //调用wxapp.php中的doPagePay方法获取支付参数
      data: {
        uid: uid,
        money: flower_money,
        video_id: id
      },
      'cachetime': '0',
      success(res) {
        console.log(res)
        var order_code = res.data.data.order_code
        console.log(order_code)
        if (res.data && res.data.data && !res.data.errno) {
          //发起支付
          wx.requestPayment({
            'timeStamp': res.data.data.timeStamp,
            'nonceStr': res.data.data.nonceStr,
            'package': res.data.data.package,
            'signType': 'MD5',
            'paySign': res.data.data.paySign,
            'success': function (res) {
              app.util.request({
                url: 'entry/wxapp/pay_success',
                method: 'POST',
                data: {
                  order_code: order_code
                },
                headers: {
                  'Content-Type': 'application/json'
                },
                success: function (res) {
                  _that.setData({
                    dis_flo: true
                  })
                  _that.onShow()
                }
              })
            },
            'fail': function (res) {
              console.log(res)
            }
          })
        }
      }
    })
    _that.setData({
      flower: inx,
      // inputValue: '输入你要送花的数量'
    })
  },
  tap_input() {
    this.setData({
      flower: null,
      inputValue: ''
    })
  },
  //input输入
  but_input(e) {
    this.setData({
      inputValue: e.detail.value
    })
    console.log(this.data.inputValue)
  },
  //送花
  tap_disFlower() {
    this.setData({
      dis_flo: !this.data.dis_flo
    })
  },
  //赠送
  tap_graded() {
    var _that = this;
    if (_that.data.flower != null) {
      var num = _that.data.flower_data[_that.data.flower].num
    }
    if (num == 0 || _that.data.inputValue == 0) {
      wx.showToast({
        title: '最少赠送一朵鲜花',
        icon: 'success',
        duration: 2000
      })
      return false
    }
    if (_that.data.flower_my < num || _that.data.flower_my < _that.data.inputValue) {
      wx.showModal({
        content: '您的鲜花不足，点击确定去领取',
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }
    if (_that.data.flower_my > num || _that.data.flower_my > _that.data.inputValue) {
      wx.showToast({
        title: '赠送成功',
        icon: 'success',
        duration: 2000
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var _that = this
    var id = options.id
    var uid = wx.getStorageSync('uid');
    console.log(id,uid)
    _that.setData({
      id: id,
      uid:uid
    })
    _that.load(id,uid);
  },
  load: function (id, uid) {
    var _that = this
    app.util.request({
      url: 'entry/wxapp/flower_list',
      data: {
        video_id: id,
        uid: uid
      },
      headers: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        console.log(res.data.data)
        var list = res.data.data.flower_list
        _that.setData({
          ranking_list_data: list,
          my_info: res.data.data.my_info,
          flower_data: res.data.data.flower_data,
          video_desc: res.data.data.video_desc,
          flower_num: res.data.data.flower_num,
          body: true
        })
        for (var i = 0; i < list.length; i++) {
          if (list[i].id == _that.data.my_info.id) {
            _that.setData({
              ranking: i + 1
            })
            return false
          }
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var id = this.data.id
    var uid = this.data.uid
    this.load(id, uid);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})