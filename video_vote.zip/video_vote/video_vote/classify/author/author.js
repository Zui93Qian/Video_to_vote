// pages/author/author.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    butTab: 0,
    lefr_height: 0,
    right_height: 0,
    text_left: [],
    text_right: [],
    text_data: [{
      he: 200,
      img: "../../image/img/lun_bo.png"
    }, {
      he: 400,
      img: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1561980668540&di=7b7d3cd229e7bf97c8c90dfb9097934d&imgtype=0&src=http%3A%2F%2Fcbu01.alicdn.com%2Fimg%2Fibank%2F2018%2F611%2F825%2F9496528116_1976887869.jpg"
    }, {
      he: 300,
      img: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1561980668540&di=7b7d3cd229e7bf97c8c90dfb9097934d&imgtype=0&src=http%3A%2F%2Fcbu01.alicdn.com%2Fimg%2Fibank%2F2018%2F611%2F825%2F9496528116_1976887869.jpg"
    }, {
      he: 200,
      img: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1561980668540&di=7b7d3cd229e7bf97c8c90dfb9097934d&imgtype=0&src=http%3A%2F%2Fcbu01.alicdn.com%2Fimg%2Fibank%2F2018%2F611%2F825%2F9496528116_1976887869.jpg"
    }, {
      he: 400,
      img: "../../image/img/lun_bo.png"
    }, {
      he: 200,
      img: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1561980668540&di=7b7d3cd229e7bf97c8c90dfb9097934d&imgtype=0&src=http%3A%2F%2Fcbu01.alicdn.com%2Fimg%2Fibank%2F2018%2F611%2F825%2F9496528116_1976887869.jpg"
    }, {
      he: 150,
      img: "../../image/img/lun_bo.png"
    }],
    my_works_data: [{
      title: "广场舞",
      img: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1561980668540&di=7b7d3cd229e7bf97c8c90dfb9097934d&imgtype=0&src=http%3A%2F%2Fcbu01.alicdn.com%2Fimg%2Fibank%2F2018%2F611%2F825%2F9496528116_1976887869.jpg"
    }, {
      title: "爱生活",
      img: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1561980668540&di=7b7d3cd229e7bf97c8c90dfb9097934d&imgtype=0&src=http%3A%2F%2Fcbu01.alicdn.com%2Fimg%2Fibank%2F2018%2F611%2F825%2F9496528116_1976887869.jpg",
    }, {
      title: "达人秀",
      img: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1561980780813&di=30fea7d427224d1f9ef62221378c825d&imgtype=0&src=http%3A%2F%2Fimg4.duitang.com%2Fuploads%2Fitem%2F201312%2F05%2F20131205171752_4AJKT.thumb.700_0.jpeg",
    }, {
      title: "流行舞",
      img: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1561980668540&di=7b7d3cd229e7bf97c8c90dfb9097934d&imgtype=0&src=http%3A%2F%2Fcbu01.alicdn.com%2Fimg%2Fibank%2F2018%2F611%2F825%2F9496528116_1976887869.jpg",
    }, {
      title: "双人舞",
      img: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1561980668540&di=7b7d3cd229e7bf97c8c90dfb9097934d&imgtype=0&src=http%3A%2F%2Fcbu01.alicdn.com%2Fimg%2Fibank%2F2018%2F611%2F825%2F9496528116_1976887869.jpg",
    }, {
      title: "民族舞",
      img: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1561980668540&di=7b7d3cd229e7bf97c8c90dfb9097934d&imgtype=0&src=http%3A%2F%2Fcbu01.alicdn.com%2Fimg%2Fibank%2F2018%2F611%2F825%2F9496528116_1976887869.jpg",
    }]
  },
  tap_butTab(e) {
    var _that = this;
    var inx = e.currentTarget.dataset.inx;
    if (inx == 0) {
      this.setData({
        butTab: 0
      })
    }
    if (inx == 1) {
      this.setData({
        butTab: 1
      })
    }
  },
  //视频详情
  tao_imgTab(e) {
    wx.navigateTo({
      url: '../../classify/details/details',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _that = this;
    var lefr_height = _that.data.lefr_height;
    var right_height = _that.data.right_height;
    var leftList = _that.data.text_left;
    var reightList = _that.data.text_right;
    for (var i = 0; i < _that.data.text_data.length; i++) {
      console.log(lefr_height + "--" + right_height)
      if (lefr_height == right_height) {
        leftList.push(_that.data.text_data[i]);
        lefr_height += _that.data.text_data[i].he
      } else if (lefr_height > right_height) {
        reightList.push(_that.data.text_data[i]);
        right_height += _that.data.text_data[i].he;
      } else if (lefr_height < right_height) {
        leftList.push(_that.data.text_data[i]);
        lefr_height += _that.data.text_data[i].he
      }
      this.setData({
        lefr_height: lefr_height,
        right_height: right_height,
        text_left: leftList,
        text_right: reightList

      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})