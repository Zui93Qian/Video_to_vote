// pages/classify/classify/classify.js
var app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    body:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var _that = this;
    app.util.request({
      url: 'entry/wxapp/category',
      data: {

      },
      headers: {
        'Content-Type': 'application/json'
      },
      success: function(res) {
        _that.setData({
          classify_data: res.data.data,
          body:true
        })
      }
    })
  },
  tap_derails(e) {
    var _that = this;
    var id = e.currentTarget.dataset.id;
    app.util.request({
      url: 'entry/wxapp/cate_video',
      data: {
        id: id
      },
      headers: {
        'Content-Type': 'application/json'
      },
      success: function(res) {
        wx.navigateTo({
          url: '../../home/video/video?id='+id,
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.onLoad()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})