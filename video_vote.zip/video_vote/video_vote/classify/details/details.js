// pages/classify/details/details.js
var app = getApp();
Page({
  /** 
   * 页面的初始数据
   */
  data: {
    body:false, //页面总体加载
    tab_inx: 0,
    focus:false,
    dis_flo: true,
    placeholder: "输入您要评论的内容~",
    matching_start: false,
    matching_data: "按时间",
    review: true,
    user_id: '',
    praise_inx: 0,
    lefr_height: 0,
    right_height: 0,
    text_left: [],
    text_right: [],
    flower: null, //默认送花
    inputValue: '输入你要送花的数量',
  },
  tap_but_writer() {
    // wx.navigateTo({
    //   url: '../../classify/author/author',
    // })
  },
  //赞
  tap_praise(e){
    var _that = this
    var state = e.currentTarget.dataset.state;
    var video_review_id = e.currentTarget.dataset.video_review_id;
    var give_like = e.currentTarget.dataset.give_like;
    var uid = _that.data.uid
    var id = _that.data.id
    if (state == 2){
      var inx = e.currentTarget.dataset.inx;
      var recommend_data = _that.data.recommend_data
    }
    if (state == 1) {
      var commect_user = _that.data.commect_user
    }
    if (give_like == 0){
      var status =1
    }
    if (give_like == 1) {
      var status = 0
    }
    app.util.request({
      url: 'entry/wxapp/give_like',
      data: {
        status: status,
        uid: uid,
        video_id: id,
        comment_id: video_review_id
      },
      headers: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        console.log(res.data.data)
        if (state == 2) {
          recommend_data[inx].give_like = res.data.data.is_zan
          recommend_data[inx].give_like_all = res.data.data.give_like_all
          _that.setData({
            recommend_data: recommend_data
          })
        }
        if (state == 1) {
          commect_user.give_like = res.data.data.is_zan
          commect_user.give_like_all = res.data.data.give_like_all
          _that.setData({
            commect_user: commect_user
          })
        }
        
      }
    })

  },
  //踩
  tap_trample(e) {
    var _that = this
    var video_review_id = e.currentTarget.dataset.video_review_id;
    var tread = e.currentTarget.dataset.tread;
    var uid = _that.data.uid
    var id = _that.data.id
    if (tread == 0) {
      var status = 1
    }
    if (tread == 1) {
      var status = 0
    }
    var state = e.currentTarget.dataset.state;
    if (state == 2){
      var inx = e.currentTarget.dataset.inx;
      var recommend_data = _that.data.recommend_data
    }
    if (state == 1) {
      var commect_user = _that.data.commect_user
    }
    app.util.request({
      url: 'entry/wxapp/tread',
      data: {
        status: status,
        uid: uid,
        video_id: id,
        comment_id:video_review_id
      },
      headers: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        console.log(res.data.data)
        if (state == 2) {
          recommend_data[inx].tread = res.data.data.is_cai
          recommend_data[inx].tread_all = res.data.data.tread_all
          _that.setData({
            recommend_data: recommend_data
          })
        }
        if (state == 1) {
          commect_user.tread = res.data.data.is_cai
          _that.setData({
            commect_user: commect_user
          })
        }
      }
    })
  },
  //立即评论
  tap_review(e) {
    var _that = this;
    var user_id = e.currentTarget.dataset.user_id;
    var user_name = e.currentTarget.dataset.user_name;
    var comment_id = e.currentTarget.dataset.comment_id;
    var inx = e.currentTarget.dataset.inx;
    var comment = e.currentTarget.dataset.comment;
    _that.setData({
      user_id: user_id,
      placeholder: '回复' + user_name + ':',
      comment_id: comment_id,
      inx: inx,
      jie_kou: 'comment',
      focus:true
    })
  },
  //input输入评论
  tap_blur(e) {
    this.setData({
        input_value: e.detail.value
    })
  },
  //发送
  tap_send() {
    var _that = this;
    var jie_kou = _that.data.jie_kou
    var id = _that.data.id
    var uid = _that.data.uid
    var input_value = _that.data.input_value
    if (!input_value){
      wx.showToast({
        title: '评论内容不能为空！',
        icon: 'none',
        duration: 2000
      })
      return false
    }
    var recommend_data = _that.data.recommend_data
    var commect_all = _that.data.commect_all
    if (jie_kou == 'comment') {
      var comment_id = _that.data.comment_id
      var user_id = _that.data.user_id
      var inx = _that.data.inx
      app.util.request({
        url: 'entry/wxapp/comment',
        data: {
          user_id: user_id,
          uid: uid,
          video_id: id,
          content: input_value,
          comment_id: comment_id
        },
        headers: {
          'Content-Type': 'application/json'
        },
        success: function(res) {
          if (inx || inx == 0) {
            if (!recommend_data[inx].reply){
              recommend_data[inx].reply = []
              recommend_data[inx].reply.push(res.data.data.arr)
            }else{
              recommend_data[inx].reply.push(res.data.data.arr)
            }
          }else{
            recommend_data.unshift(res.data.data.arr)
          }
          _that.setData({
            recommend_data: recommend_data,
            comment_id: '',
            placeholder: '输入您要评论的内容~',
            val: '',
            input_value:'',
            inx: null,
            focus: false
          })
          
        }
      })
    }
    if (jie_kou == 'all_replay'){
      var comment_id = _that.data.comment_id
      app.util.request({
        url: 'entry/wxapp/all_replay',
        data: {
          video_id: id,
          comment_id: comment_id,
          uid: uid,
          content: input_value
        },
        headers: {
          'Content-Type': 'application/json'
        },
        success: function (res) {
          console.log(res.data.data)
          commect_all.unshift(res.data.data)
          _that.setData({
            commect_all: commect_all,
            comment_id: '',
            placeholder: '输入您要评论的内容~',
            val: '',
            inx: null,
            input_value:'',
            review: false,
            focus: false
          })
        }
      })
    }
  },
  //分享
  tap_share() {
    wx.updateShareMenu({
      withShareTicket: true,
      success() {
        wx.showToast({
          title: '分享成功',
          icon: 'success',
          duration: 2000
        })
      }
    })
  },
  //小导航
  tap_but(e) {
    var _that = this;
    var inx = e.currentTarget.dataset.inx;
    var id = _that.data.id
    if (inx == 0) {
      _that.setData({
        tab_inx: 0
      })
    }
    if (inx == 1) {
      _that.commect_list(id);
      _that.setData({
        tab_inx: 1,
        jie_kou:"comment",
        inx: null,
        comment_id:''
      })
    }
  },
  commect_list(id) {
    var _that = this
    var uid = _that.data.uid
    app.util.request({

      url: 'entry/wxapp/commect_list',
      data: {
        video_id: id,
        uid: uid
      },
      headers: {
        'Content-Type': 'application/json'
      },
      success: function(res) {
        _that.setData({
          recommend_data: res.data.data,
          review: true
        })
      }
    })
  },
  //全部回复
  tap_reply(e) {
    var _that = this;
    var commects_id = e.currentTarget.dataset.commects_id;
    var id = _that.data.id
    console.log(commects_id, id)
    app.util.request({

      url: 'entry/wxapp/commect_all',
      data: {
        comment_id: commects_id,
        id: id
      },
      headers: {
        'Content-Type': 'application/json'
      },
      success: function(res) {
        console.log(res.data.data)
        _that.setData({
          commect_all: res.data.data.commect_list,
          commect_user: res.data.data.user,
          reply_count: res.data.data.reply_count,
          review: false
        })
      }
    })
    _that.setData({
      tab_inx: 2
    })
  },
  //评论/立即回复
  tap_hf(e) {
    var _that = this
    var comment_id = e.currentTarget.dataset.comment_id;
    var all_replay = e.currentTarget.dataset.all_replay;
    _that.setData({
      jie_kou: all_replay,
      comment_id: comment_id,
      review: true,
      focus: true
    })
    
  },
  // 介绍查看
  but_introduce() {
    this.setData({
      my_introduce: false
    })
  },
  tap_introduce() {
    this.setData({
      id_introduce: false
    })
  },
  //模糊搜索
  tap_matching() {
    this.setData({
      matching_start: !this.data.matching_start
    })
  },
  //模糊搜索选择
  tap_but_matching(e) {
    var _that = this;
    var inx = e.currentTarget.dataset.inx;
    if (inx == 0) {

      _that.setData({
        matching_start: !this.data.matching_start,
        matching_data: "按时间"
      })
    }
    if (inx == 1) {

      _that.setData({
        matching_start: !this.data.matching_start,
        matching_data: "按热度"
      })
    }
  },
  //收藏
  tap_collect(e) {
    var _that = this;
    var status = e.currentTarget.dataset.status;
    if (status == 0) {
      var status_vid = 1
    }
    if (status == 1) {
      var status_vid = 0
    }
    var video_id = e.currentTarget.dataset.video_id;
    var uid = wx.getStorageSync('uid');
    app.util.request({
      url: 'entry/wxapp/collect',
      data: {
        status: status_vid,
        uid: uid,
        video_id: video_id
      },
      headers: {
        'Content-Type': 'application/json'
      },
      success: function(res) {
        var video_data1 = _that.data.video_data
        video_data1.is_collect = res.data.data.collect
        if (res.data.data.collect == 1) {
          _that.setData({
            video_data: video_data1
          })
        }
        if (res.data.data.collect == 0) {
          _that.setData({
            video_data: video_data1
          })
        }
      }
    })
  },
  //鲜花榜单
  tap_list_flowers(e) {
    var id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '../../classify/ranking_list/ranking_list?id=' + id,
    })
  },
  //详情跳转
  tao_imgTab(e) {
    var id = e.currentTarget.dataset.id;
    var uid = wx.getStorageSync('uid');
    wx.redirectTo({
      url: '../../classify/details/details?id=' + id + '&uid=' + uid,
    })
  },
  //送花选择
  tap_flowerBtn(e) {
    var _that = this;
    var inx = e.currentTarget.dataset.inx;
    var flower_money = e.currentTarget.dataset.flower_money;
    var uid = wx.getStorageSync('uid');
    var video_id = _that.data.video_data.id
    app.util.request({
      'url': 'entry/wxapp/pay', //调用wxapp.php中的doPagePay方法获取支付参数
      data: {
        uid: uid,
        money: flower_money,
        video_id: video_id
      },
      'cachetime': '0',
      success(res) {
        console.log(res)
        var order_code = res.data.data.order_code
        console.log(order_code)
        if (res.data && res.data.data && !res.data.errno) {
          //发起支付
          wx.requestPayment({
            'timeStamp': res.data.data.timeStamp,
            'nonceStr': res.data.data.nonceStr,
            'package': res.data.data.package,
            'signType': 'MD5',
            'paySign': res.data.data.paySign,
            'success': function(res) {
              app.util.request({
                url: 'entry/wxapp/pay_success',
                method: 'POST',
                data: {
                  order_code: order_code
                },
                headers: {
                  'Content-Type': 'application/json'
                },
                success: function(res) {
                  _that.setData({
                    dis_flo: true
                  })
                  _that.onShow()
                }
              })
            },
            'fail': function(res) {
              console.log(res)
            }
          })
        }
      }
    })
    _that.setData({
      flower: inx,
      // inputValue: '输入你要送花的数量'
    })
  },
  tap_input() {
    this.setData({
      flower: null,
      // inputValue: ''
    })
  },
  //input输入
  but_input(e) {
    this.setData({
      inputValue: e.detail.value
    })
    console.log(this.data.inputValue)
  },
  //送花
  tap_disFlower() {
    this.setData({
      dis_flo: !this.data.dis_flo
    })
  },
  //赠送
  tap_graded() {
    var _that = this;

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var _that = this
    _that.setData({
      id: options.id,
      uid: options.uid
    })
    _that.setData({
      winWid: wx.getSystemInfoSync().windowWidth / 2
    })
  },
  load: function(id, uid, keyword) {
    var _that = this;
    var lefr_height = _that.data.lefr_height;
    var right_height = _that.data.right_height;
    var leftList = _that.data.text_left;
    var reightList = _that.data.text_right;
    app.util.request({
      url: 'entry/wxapp/get_video_info',
      data: {
        id: id,
        uid: uid
      },
      headers: {
        'Content-Type': 'application/json'
      },
      success: function(res) {
        var text_data = res.data.data.video_list
        var winWid = _that.data.winWid
        _that.setData({
          video_data: res.data.data,
          flower_data: res.data.data.flower_data,
          flower_list: res.data.data.flower_list,
          body: true
        })
        for (var i = 0; i < text_data.length; i++) {
          var imgh = text_data[i].height; //图片高度
          var imgw = text_data[i].width; //图片宽度
          var swiperH = parseInt(winWid * imgh / imgw)
          text_data[i].height = swiperH
          if (lefr_height == right_height) {
            lefr_height += text_data[i].height;
            leftList.push(text_data[i]);
          } else if (lefr_height > right_height) {
            right_height += text_data[i].height;
            reightList.push(text_data[i]);
          } else {
            lefr_height += text_data[i].height;
            leftList.push(text_data[i]);
          }
          console.log(text_data[i].height, lefr_height, right_height)
          _that.setData({
            text_data: text_data,
            lefr_height: lefr_height,
            right_height: right_height,
            text_left: leftList,
            text_right: reightList
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var _that = this
    var id = _that.data.id
    var uid = _that.data.uid
    _that.unset(this);
    _that.load(id, uid);
  },
  unset(_that) {
    _that.setData({
      lefr_height: 0,
      right_height: 0,
      text_left: [],
      text_right: []
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})