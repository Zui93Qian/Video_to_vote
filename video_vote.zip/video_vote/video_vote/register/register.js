var app = getApp();

Page({
  data: {
    login_image: ''
  },
  onLoad: function() {
    var uid = wx.getStorageSync('uid');
    if (uid) {
      wx.reLaunch({
        url: "../home/index/index"
      });
    } else {
      var that = this;
      app.util.request({
        url: 'entry/wxapp/getsetting',
        method: 'POST',
        data: {},
        headers: {
          'Content-Type': 'application/json'
        },
        success: function(res) {
          that.setData({
            login_image: res.data.data.logo
          })
        }
      })
    }
  },
  //获取用户信息新接口
  getUserInfo: function(e) {
    var that = this;
    if (e.detail.userInfo) {
      //设置用户信息本地存储
      wx.login({
        success: res => {
          var t = e.detail;
          if (res.code) {
            app.util.request({
              url: 'entry/wxapp/getopenid',
              method: 'POST',
              data: {
                code: res.code
              },
              headers: {
                'Content-Type': 'application/json'
              },
              success: function(res) {
                if (res.data.errno == '0') {
                  t.openid = res.data.data.openid,
                    t.session_key = res.data.data.session_key,
                    wx.setStorageSync("wxuser", e);
                  wx.showToast({
                    title: "授权成功",
                    icon: 'none'
                  })
                  that.register(function(res) {})
                }
              }
            })
          } else {
            console.log('获取用户登录态失败！' + res.errMsg)
          }
        }
      })
    } else {
      wx.showToast({ //模拟请求数据中
        title: '获取信息登录失败',
        icon: 'loading',
        duration: 2000,
        success: function() {}
      })
    }
  },
  onShow: function() {},
  register: function(u) {
    var that = this;
    wx.getStorage({
      key: "wxuser",
      success: function(a) {
        var t = a.data.detail,
          o = a.data.detail.openid,
          n = (t = t.userInfo).country,
          e = t.province,
          i = t.city,
          c = t.gender,
          s = t.nickName,
          r = t.avatarUrl;
        app.util.request({
          url: "entry/wxapp/zhuce",
          method: "post",
          dataType: "json",
          data: {
            openid: o,
            nickName: s,
            gender: c,
            country: n,
            province: e,
            city: i,
            avatarUrl: r
          },
          success: function(a) {
            that.setData({
              uid: a.data.data
            });
            app.globalData.uid = a.data.data;
            wx.setStorageSync("uid", a.data.data);
            wx.reLaunch({
              url: "../home/index/index"
            });
          }
        });
      },
      fail: function(a) {
        t.setData({});
      }
    });
  },
});