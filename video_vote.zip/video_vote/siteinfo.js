var siteinfo = {
  "uniacid": "10",//小程序uniacid
  "acid": "10",
  "multiid": "0",//小程序版本id
  "version": "1.0.0",//小程序版本
  "siteroot": "https://jud.wzhi.vip/app/index.php",//站点URL
  "token": "3"  //将用于接口中的数据安全校验
}
module.exports = siteinfo